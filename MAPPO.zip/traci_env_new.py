"""
traci_env.py
============
SUMO TraCI environment — FINAL production version.

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
REWARD  (simple, clean, fully defensible in thesis)
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

  R_i = -(0.5·NormQueue + 0.3·NormDelay + 0.2·NormWait)

  Term        Weight  Formula                          Purpose
  ─────────── ──────  ───────────────────────────────  ────────────────────────
  NormQueue    0.5    mean_halting / Q_MAX             Dominant congestion signal
  NormDelay    0.3    mean(1-speed/free_speed) ∈[0,1] Gradient when queue=0
  NormWait     0.2    mean(total_wait/n_veh) / W_MAX  Fairness — no lane ignored

  Key properties:
  • Weights sum to 1.0 → reward always in [-1.0, 0] → stable PPO value function
  • No action-change penalty: MIN_GREEN_STEPS=10 already mechanically blocks
    flickering — a soft penalty on top would send contradictory gradients
  • No pressure term: T-junctions with simultaneous E/W green at n_1_1
    make pressure systematically biased — omitted deliberately
  • No delta term: simpler training signal, easier thesis defence
  • Cited basis: Kwesiga et al. 2024 (MAPPO-ATSC) uses equivalent structure

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
SIGNAL CONTROL  (SUMO-native yellow timer — 3 rules)
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

  Rule 1 — Never interrupt yellow:
    Read traci.trafficlight.getPhase(). If ODD → yellow is active.
    Skip setPhase entirely. SUMO's built-in timer runs the exact 3s
    yellow from net.xml then auto-advances. Calling setPhase during
    yellow resets the timer → original green→green bug returns.

  Rule 2 — Minimum green hold (MIN_GREEN_STEPS = 10s):
    Count steps since last green started. Block any switch request
    until the threshold is met.

  Rule 3 — Switch via yellow (once):
    Call setPhase(current + 1) exactly once. Then stop calling setPhase.
    SUMO advances yellow → next green automatically.

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
BUGS FIXED vs earlier versions
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
  BUG 1: traci.junction.getIncomingEdges() does not exist in TraCI API
         → AttributeError crash on first episode
         FIXED: traci.trafficlight.getControlledLanes(jid)

  BUG 2: traci.lane.getWaitingTime() returns TOTAL for all vehicles
         → reward diverges (600s total / W_MAX=120 >> 1)
         FIXED: total_wait / max(1, n_veh) gives per-vehicle average

  BUG 3: setPhase called every step during yellow → timer reset
         → green→green jump, no vehicle clearance
         FIXED: SUMO-native timer (Rule 1)
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
"""

import os, sys, time
import numpy as np
from collections import defaultdict

# ── SUMO / TraCI ──────────────────────────────────────────────────────────────
if "SUMO_HOME" not in os.environ:
    for c in ["/usr/share/sumo",
              "/opt/homebrew/share/sumo",
              "C:/Program Files (x86)/Eclipse/Sumo"]:
        if os.path.exists(c):
            os.environ["SUMO_HOME"] = c
            break

if "SUMO_HOME" in os.environ:
    sys.path.append(os.path.join(os.environ["SUMO_HOME"], "tools"))
else:
    raise EnvironmentError("SUMO_HOME not set. Install SUMO and set the env variable.")

try:
    import traci
except ImportError:
    raise ImportError("TraCI not found. Is SUMO installed?")

from gcn_encoder import (
    REAL_JUNCTIONS, JUNCTION_LANES, RAW_OBS_DIM,
    GREEN_PHASES, ACT_DIM,
)
from mappo_atsc import MAPPOController, ROLLOUT_LEN, MAX_EPISODES

# ── Simulation config ─────────────────────────────────────────────────────────
SUMO_CFG        = "run.sumocfg"
USE_GUI         = False
DELTA_T         = 1.0          # seconds per simulation step
WARMUP_STEPS    = 900          # 15-min warm-up  (no agent control)
EP_DURATION     = 2700         # 45-min episode  → 900+2700=3600s = matches Gridnetwork.py SIM_DURATION=3600
DETECTION_RANGE = 100.0        # metres ahead of stop-line for queue counts
MIN_GREEN_STEPS = 10           # minimum green hold before switch allowed

# ── Multi-density route files ─────────────────────────────────────────────────
# Pass density="low"/"medium"/"high" to SUMOEnv to match your curriculum setup.
# Each file should be generated once with different vehsPerHour values.
# If a density file is missing, the env falls back to DEFAULT_ROUTE_FILE.
DENSITY_ROUTE_FILES = {
    "low":    "low_routes.rou.xml",     # off-peak   ~824  veh/hr
    "medium": "medium_routes.rou.xml",  # mid-day    ~1685 veh/hr
    "high":   "high_routes.rou.xml",    # peak-hour  ~3376 veh/hr
}
DEFAULT_ROUTE_FILE = "final_routes.rou.xml"  # used when density=None

# ── Reward constants  R = -(0.5·Queue + 0.3·Delay + 0.2·Wait) ───────────────
W_QUEUE = 0.5    # halting vehicles — dominant term
W_DELAY = 0.3    # fractional speed loss
W_WAIT  = 0.2    # per-vehicle waiting time
Q_MAX   = 20.0   # normalisation cap: halting vehicles per lane
W_MAX   = 60.0   # normalisation cap: per-vehicle wait time (seconds)


# ══════════════════════════════════════════════════════════════════════════════
#  ENVIRONMENT
# ══════════════════════════════════════════════════════════════════════════════

class SUMOEnv:
    """
    SUMO TraCI environment for Manhattan 4×4 grid.
    Signal control : SUMO-native yellow timer (3-rule approach).
    Reward         : R = -(0.5·NormQueue + 0.3·NormDelay + 0.2·NormWait)
    Timing         : WARMUP=900s + EP_DURATION=2700s = 3600s (matches Gridnetwork.py)
    Multi-density  : Pass density='low'/'medium'/'high' to switch route files.
    """

    def __init__(self, sumocfg=SUMO_CFG, use_gui=USE_GUI,
                 warmup=WARMUP_STEPS, ep_duration=EP_DURATION,
                 delta_t=DELTA_T, density: str = None):
        """
        Args:
            density: None (default route) | 'low' | 'medium' | 'high'
                     Selects the route file for this environment instance.
                     Use this for curriculum / peak-hour training.
        """
        self.density   = density
        self.cfg       = self._resolve_config(sumocfg)
        self.use_gui   = use_gui
        self.warmup    = warmup
        self.ep_dur    = ep_duration
        self.delta_t   = delta_t
        self.sim_step  = 0
        # Initialised properly in reset()
        self._lane_cache:   dict = {}
        self._departed:     dict = {}
        self._arrived:      dict = {}
        self._green_hold:   dict = {}
        self._last_action:  dict = {}

    def _resolve_config(self, base_cfg: str) -> str:
        """
        If a density-specific route file exists, write a temp config pointing
        to it and return its path. Otherwise return the original config.
        This lets you switch traffic density without editing run.sumocfg.
        """
        if self.density is None:
            return base_cfg
        route_file = DENSITY_ROUTE_FILES.get(self.density, DEFAULT_ROUTE_FILE)
        if not os.path.exists(route_file):
            print(f"  [SUMOEnv] Warning: {route_file} not found, using {DEFAULT_ROUTE_FILE}")
            return base_cfg
        # Write a temporary config file pointing to the density route file
        import xml.etree.ElementTree as ET
        cfg_path = f"run_{self.density}.sumocfg"
        net_file = "manhattan.net.xml"
        with open(cfg_path, "w") as f:
            f.write(f"""<configuration>
    <input>
        <net-file value="{net_file}"/>
        <route-files value="{route_file}"/>
    </input>
    <time>
        <begin value="0"/>
    </time>
</configuration>
""")
        print(f"  [SUMOEnv] density={self.density} → {route_file}")
        return cfg_path

    # ── Lifecycle ─────────────────────────────────────────────────────────────

    def _launch(self):
        binary = "sumo-gui" if self.use_gui else "sumo"
        traci.start([
            binary, "-c", self.cfg,
            "--step-length",      str(self.delta_t),
            "--time-to-teleport", "-1",
            "--no-warnings",      "true",
            "--log",              "/dev/null",
        ])

    def reset(self) -> dict:
        if traci.isLoaded():
            traci.close()
            time.sleep(0.2)
        self._launch()
        self.sim_step   = 0
        self._departed  = {}
        self._arrived   = {}
        self._lane_cache = {}
        self._green_hold  = {jid: 0 for jid in REAL_JUNCTIONS}
        self._last_action = {jid: 0 for jid in REAL_JUNCTIONS}

        # Warm-up: let SUMO run on its default fixed-time plan
        for _ in range(self.warmup):
            traci.simulationStep()
            self.sim_step += 1
            self._track_vehicles()

        # Build lane cache once after warm-up (SUMO fully loaded)
        self._build_lane_cache()
        return self._get_obs()

    def step(self, actions: dict):
        self._apply_actions(actions)
        traci.simulationStep()
        self.sim_step += 1
        self._track_vehicles()
        obs  = self._get_obs()
        rews = self._compute_rewards()
        done = self.sim_step >= (self.warmup + self.ep_dur)
        info = {"avg_tt": self.avg_tt(), "step": self.sim_step}
        return obs, rews, done, info

    def close(self):
        if traci.isLoaded():
            traci.close()

    # ── Lane cache (built once per episode) ──────────────────────────────────

    def _build_lane_cache(self):
        """
        FIX 1: Use traci.trafficlight.getControlledLanes() — the correct API.
        traci.junction.getIncomingEdges() does NOT exist and crashes at runtime.
        """
        for jid in REAL_JUNCTIONS:
            try:
                raw  = traci.trafficlight.getControlledLanes(jid)
                seen, dedup = set(), []
                for lid in raw:
                    if lid not in seen:
                        seen.add(lid)
                        dedup.append(lid)
                self._lane_cache[jid] = dedup
            except traci.TraCIException:
                self._lane_cache[jid] = []

    def _lanes(self, jid: str) -> list:
        if not self._lane_cache:
            self._build_lane_cache()
        return self._lane_cache.get(jid, [])

    # ── Observation ───────────────────────────────────────────────────────────

    def _get_obs(self) -> dict:
        """
        obs[jid] shape = (JUNCTION_LANES[jid] + 1,)
          [veh_count_lane_0, …, veh_count_lane_N-1, current_action_idx]
        Counts vehicles within DETECTION_RANGE of stop-line only.
        """
        out = {}
        for jid in REAL_JUNCTIONS:
            lanes  = self._lanes(jid)
            n      = JUNCTION_LANES[jid]
            counts = np.zeros(n, dtype=np.float32)
            for li, lid in enumerate(lanes[:n]):
                try:
                    c = 0
                    for vid in traci.lane.getLastStepVehicleIDs(lid):
                        pos = traci.vehicle.getLanePosition(vid)
                        if traci.lane.getLength(lid) - pos <= DETECTION_RANGE:
                            c += 1
                    counts[li] = float(c)
                except traci.TraCIException:
                    pass
            out[jid] = np.append(counts, float(self._last_action[jid])).astype(np.float32)
        return out

    # ── Reward: R = -(0.5·NormQueue + 0.3·NormDelay + 0.2·NormWait) ──────────

    def _compute_rewards(self) -> dict:
        """
        Three-term reward per junction — simple, clean, thesis-defensible.

        NormQueue = mean halting vehicles per lane / Q_MAX
        NormDelay = mean(1 - speed/free_speed) per lane, clamped to [0,1]
        NormWait  = mean per-vehicle waiting time per lane / W_MAX
                    (total_wait / max(1, n_veh) to avoid scale explosion)

        Reward is always in [-1.0, 0]. Clean range for PPO value function.
        """
        rews = {}
        for jid in REAL_JUNCTIONS:
            lanes = self._lanes(jid)
            q_list, d_list, w_list = [], [], []

            for lid in lanes:
                try:
                    n_veh   = traci.lane.getLastStepVehicleNumber(lid)
                    halting = float(traci.lane.getLastStepHaltingNumber(lid))
                    q_list.append(halting)

                    # Fractional delay: 0 = free flow, 1 = full stop
                    free_v = traci.lane.getMaxSpeed(lid)
                    mean_v = traci.lane.getLastStepMeanSpeed(lid)
                    if free_v > 0:
                        d_list.append(max(0.0, 1.0 - mean_v / free_v))

                    # Per-vehicle wait — divide by count to avoid scale explosion
                    total_wait = float(traci.lane.getWaitingTime(lid))
                    w_list.append(total_wait / max(1, n_veh))

                except traci.TraCIException:
                    pass

            q_mean = float(np.mean(q_list)) if q_list else 0.0
            d_mean = float(np.mean(d_list)) if d_list else 0.0
            w_mean = float(np.mean(w_list)) if w_list else 0.0

            rews[jid] = -(
                W_QUEUE * min(q_mean, Q_MAX) / Q_MAX +
                W_DELAY * min(d_mean, 1.0)           +
                W_WAIT  * min(w_mean, W_MAX) / W_MAX
            )
        return rews

    # ── Signal Control: SUMO-native 3-rule approach ───────────────────────────

    def _apply_actions(self, actions: dict):
        """
        Apply MAPPO actions with SUMO-native yellow timer.

        Rule 1: current SUMO phase is ODD → yellow is active → do NOT call
                setPhase. SUMO's built-in timer runs the exact 3s yellow
                from net.xml then auto-advances. Calling setPhase during
                yellow resets the timer — the original green→green bug.

        Rule 2: green_hold < MIN_GREEN_STEPS=10 → hold current green,
                block the switch request until minimum is met.

        Rule 3: switch allowed → setPhase(current + 1) ONCE.
                SUMO advances yellow → next green automatically.
        """
        for jid, agent_action in actions.items():
            try:
                gps           = GREEN_PHASES[jid]
                agent_action  = int(agent_action) % len(gps)
                desired_green = gps[agent_action]   # SUMO phase index (0 or 2)

                current_phase = traci.trafficlight.getPhase(jid)

                # ── Rule 1: ODD = yellow → hands off ─────────────────────────
                if current_phase % 2 == 1:
                    self._green_hold[jid] = 0
                    continue   # do NOT call setPhase

                # ── Even = green → agent has control ─────────────────────────
                self._green_hold[jid] += 1
                min_met = self._green_hold[jid] >= MIN_GREEN_STEPS

                if desired_green != current_phase and min_met:
                    # ── Rule 3: initiate switch via yellow ────────────────────
                    traci.trafficlight.setPhase(jid, current_phase + 1)
                    self._green_hold[jid]  = 0
                    self._last_action[jid] = agent_action
                else:
                    # Hold current green (same direction OR minimum not met)
                    if current_phase not in gps:
                        traci.trafficlight.setPhase(jid, desired_green)
                    else:
                        traci.trafficlight.setPhase(jid, current_phase)
                    self._last_action[jid] = (gps.index(current_phase)
                                              if current_phase in gps
                                              else agent_action)

            except (traci.TraCIException, KeyError, ValueError):
                pass

    # ── Vehicle tracking ──────────────────────────────────────────────────────

    def _track_vehicles(self):
        t = self.sim_step * self.delta_t
        for vid in traci.vehicle.getIDList():
            if vid not in self._departed:
                self._departed[vid] = t
        for vid in traci.simulation.getArrivedIDList():
            if vid in self._departed:
                self._arrived[vid] = t - self._departed[vid]

    def avg_tt(self) -> float:
        return float(np.mean(list(self._arrived.values()))) if self._arrived else 0.0


# ══════════════════════════════════════════════════════════════════════════════
#  TRAINING LOOP
# ══════════════════════════════════════════════════════════════════════════════

def _get_density_for_episode(ep: int, n_episodes: int) -> str:
    """
    Curriculum schedule:
      Stage 1 (first 25%):  low     — off-peak   ~824  veh/hr
      Stage 2 (next 25%):   medium  — mid-day    ~1685 veh/hr
      Stage 3 (last 50%):   high    — peak-hour  ~3376 veh/hr
    """
    frac = ep / n_episodes
    if frac < 0.25:
        return "low"
    elif frac < 0.50:
        return "medium"
    else:
        return "high"


def train(n_episodes: int = MAX_EPISODES,
          device:     str = "cpu",
          save_dir:   str = "ckpt_mappo",
          resume_from: str = None,
          use_gui:    bool = False,
          curriculum: bool = False,
          density:    str = None):
    """
    Full GCN-MAPPO training loop.

    Episode structure  (matches Gridnetwork.py SIM_DURATION = 3600s):
      15 min (900s)  warm-up  — SUMO default fixed-time plan, no agent
      45 min (2700s) learning — agent controls, MAPPO updates every ROLLOUT_LEN steps
      Total: 3600s = 1 hour per episode

    Curriculum mode (--curriculum flag):
      Episodes 1–25%:   low density    (off-peak,   ~824  veh/hr)
      Episodes 25–50%:  medium density (mid-day,    ~1685 veh/hr)
      Episodes 50–100%: high density   (peak-hour,  ~3376 veh/hr)
      Requires: low_routes.rou.xml, medium_routes.rou.xml, high_routes.rou.xml
      Generate with: python generate_density_routes.py

    Checkpoints : every 50 episodes + on new best travel time
    Evaluation  : every 100 episodes (5 episodes, no gradient)
    """
    print("=" * 70)
    print(f"  GCN-MAPPO Training  |  device={device}  |  episodes={n_episodes}")
    print("  Reward     : -(0.5·NormQueue + 0.3·NormDelay + 0.2·NormWait)")
    print("  Signal     : SUMO-native yellow timer  |  min green = 10s")
    print(f"  Episode    : {WARMUP_STEPS}s warmup + {EP_DURATION}s training = {WARMUP_STEPS+EP_DURATION}s total")
    print(f"  Curriculum : {'ON' if curriculum else 'OFF'}")
    print("=" * 70)

    ctrl      = MAPPOController(device=device)
    if resume_from:
        ctrl.load(resume_from)
    best_tt   = float("inf")
    ep_log    = []
    rollout_n = 0

    for ep in range(1, n_episodes + 1):
        # Select density for this episode (curriculum or fixed)
        ep_density = _get_density_for_episode(ep, n_episodes) if curriculum else density
        env     = SUMOEnv(use_gui=use_gui, density=ep_density)

        t0      = time.time()
        raw_obs = env.reset()
        ep_rew  = defaultdict(float)
        done    = False
        step_n  = 0

        while not done:
            acts, lps, vals, aug, gs = ctrl.act(raw_obs)
            raw_obs, rews, done, info = env.step(acts)
            ctrl.store(aug, gs, acts, lps, rews, vals, done)
            for jid in REAL_JUNCTIONS:
                ep_rew[jid] += rews.get(jid, 0.0)
            rollout_n += 1
            step_n    += 1
            if rollout_n >= ROLLOUT_LEN or done:
                ctrl.update(raw_obs)
                rollout_n = 0

        env.close()

        avg_rew = float(np.mean(list(ep_rew.values())))
        avg_tt  = env.avg_tt()
        ep_log.append({"ep": ep, "avg_rew": avg_rew, "avg_tt": avg_tt,
                        "density": ep_density or "default"})

        dens_tag = f"[{ep_density or 'default':7s}]"
        print(f"  Ep {ep:4d}/{n_episodes} {dens_tag} | "
              f"reward={avg_rew:7.4f} | tt={avg_tt:6.1f}s | "
              f"steps={step_n:5d} | t={time.time()-t0:.0f}s")

        if ep % 50 == 0:
            ctrl.save(save_dir)
        if avg_tt > 0 and avg_tt < best_tt:
            best_tt = avg_tt
            ctrl.save(save_dir + "_best")
            print(f"  ★  New best travel time: {best_tt:.1f}s")
        if ep % 100 == 0:
            print(f"\n  Evaluating at episode {ep} ...")
            _evaluate(ctrl, n_reps=5, use_gui=False)
            print()

    ctrl.save(save_dir + "_final")
    _save_log(ep_log, save_dir)
    print(f"\n  Training complete. Best avg travel time: {best_tt:.1f}s")
    return ctrl


def _evaluate(ctrl: MAPPOController, n_reps: int = 5, use_gui: bool = False,
              density: str = None):
    """Run evaluation episodes with no parameter updates."""
    tt_l, r_l = [], []
    for _ in range(n_reps):
        env  = SUMOEnv(use_gui=use_gui, density=density)
        raw  = env.reset()
        done = False
        ep_r = defaultdict(float)
        while not done:
            acts, *_ = ctrl.act(raw)
            raw, rews, done, _ = env.step(acts)
            for jid in REAL_JUNCTIONS:
                ep_r[jid] += rews.get(jid, 0.0)
        tt_l.append(env.avg_tt())
        r_l.append(float(np.mean(list(ep_r.values()))))
        env.close()
    print(f"  Eval ({n_reps} reps): "
          f"travel_time = {np.mean(tt_l):.1f} ± {np.std(tt_l):.1f}s  |  "
          f"reward = {np.mean(r_l):.4f}")


def _save_log(log: list, directory: str):
    os.makedirs(directory, exist_ok=True)
    path = os.path.join(directory, "training_log.csv")
    with open(path, "w") as f:
        f.write("episode,avg_reward,avg_travel_time,density\n")
        for r in log:
            f.write(f"{r['ep']},{r['avg_rew']:.4f},{r['avg_tt']:.2f},{r.get('density','default')}\n")
    print(f"  Log saved -> {path}")


# ══════════════════════════════════════════════════════════════════════════════
#  ENTRY POINT
# ══════════════════════════════════════════════════════════════════════════════

if __name__ == "__main__":
    import argparse
    p = argparse.ArgumentParser(description="GCN-MAPPO Traffic Signal Training")
    p.add_argument("--episodes",    type=int,  default=MAX_EPISODES)
    p.add_argument("--device",      type=str,  default="cpu", choices=["cpu","cuda"])
    p.add_argument("--save_dir",    type=str,  default="ckpt_mappo")
    p.add_argument("--resume",      type=str,  default=None)
    p.add_argument("--gui",         action="store_true")
    p.add_argument("--eval_only",   action="store_true")
    p.add_argument("--curriculum",  action="store_true",
                   help="Enable curriculum: low→medium→high density across episodes")
    p.add_argument("--density",     type=str,  default=None,
                   choices=["low","medium","high"],
                   help="Fixed density for training or evaluation")
    args = p.parse_args()

    if args.eval_only:
        ctrl = MAPPOController(device=args.device)
        if args.resume:
            ctrl.load(args.resume)
        _evaluate(ctrl, n_reps=10, use_gui=args.gui, density=args.density)
    else:
        train(n_episodes  = args.episodes,
              device       = args.device,
              save_dir     = args.save_dir,
              resume_from  = args.resume,
              use_gui      = args.gui,
              curriculum   = args.curriculum,
              density      = args.density)
