"""
traci_env_dqn.py
================
SUMO TraCI environment — adapted for Multi-Agent DQN (ma_dqn.py).

KEY CHANGES vs traci_env_new.py (MAPPO version):
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
  1. Removed ALL imports of mappo_atsc / MAPPOController.
  2. train() loop uses MADQNController — replay buffer + batch updates.
  3. _evaluate() uses MADQNController.act() with epsilon forced to 0.
  4. save_dir default changed to "ckpt_dqn".
  5. Logging includes dqn_loss + epsilon + buffer_size.
  6. No ROLLOUT_LEN / rollout_n — DQN uses replay buffer, not rollout buffer.
  7. MAX_EPISODES imported from ma_dqn, not mappo_atsc.
  8. WARMUP_STEPS for replay buffer fill respected before first gradient update
     (handled internally in MADQNAgent — this loop just calls update every step).

SUMOEnv class is IDENTICAL to the MAPPO version — same reward, same signal
control, same observations. Only the training loop and controller differ.

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
REWARD  (identical across all three algorithms for fair comparison)
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

  R_i = -(0.5·NormQueue + 0.3·NormDelay + 0.2·NormWait)

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
SIGNAL CONTROL  (SUMO-native yellow timer — 3 rules, same as MAPPO)
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

  Rule 1 — Never interrupt yellow (ODD phase → skip setPhase).
  Rule 2 — Minimum green hold (MIN_GREEN_STEPS = 10s).
  Rule 3 — Switch via yellow (setPhase once, SUMO advances automatically).
"""

import os, sys, time
import numpy as np
from collections import defaultdict

# ── SUMO / TraCI ──────────────────────────────────────────────────────────────
if "SUMO_HOME" not in os.environ:
    for c in ["/usr/share/sumo",
              "/opt/homebrew/share/sumo",
              "C:/Program Files (x86)/Eclipse/Sumo"]:
        if os.path.exists(c):
            os.environ["SUMO_HOME"] = c
            break

if "SUMO_HOME" in os.environ:
    sys.path.append(os.path.join(os.environ["SUMO_HOME"], "tools"))
else:
    raise EnvironmentError("SUMO_HOME not set. Install SUMO and set the env variable.")

try:
    import traci
except ImportError:
    raise ImportError("TraCI not found. Is SUMO installed?")

from gcn_encoder import (
    REAL_JUNCTIONS, JUNCTION_LANES, RAW_OBS_DIM,
    GREEN_PHASES, ACT_DIM,
)

# ── DQN controller import (NOT mappo_atsc) ────────────────────────────────────
from ma_dqn import MADQNController, MAX_EPISODES

# ── Simulation config ─────────────────────────────────────────────────────────
SUMO_CFG        = "run.sumocfg"
USE_GUI         = False
DELTA_T         = 1.0
WARMUP_STEPS    = 900
EP_DURATION     = 2700
DETECTION_RANGE = 100.0
MIN_GREEN_STEPS = 10

# ── Multi-density route files ─────────────────────────────────────────────────
DENSITY_ROUTE_FILES = {
    "low":    "low_routes.rou.xml",
    "medium": "medium_routes.rou.xml",
    "high":   "high_routes.rou.xml",
}
DEFAULT_ROUTE_FILE = "final_routes.rou.xml"

# ── Reward constants ──────────────────────────────────────────────────────────
W_QUEUE = 0.5
W_DELAY = 0.3
W_WAIT  = 0.2
Q_MAX   = 20.0
W_MAX   = 60.0


# ══════════════════════════════════════════════════════════════════════════════
#  ENVIRONMENT  (identical to MAPPO version — same obs/reward/signal control)
# ══════════════════════════════════════════════════════════════════════════════

class SUMOEnv:
    """
    SUMO TraCI environment for Manhattan 4×4 grid.
    Compatible with MADQNController (ma_dqn.py).

    Signal control : SUMO-native yellow timer (3-rule approach).
    Reward         : R = -(0.5·NormQueue + 0.3·NormDelay + 0.2·NormWait)
    Timing         : WARMUP=900s + EP_DURATION=2700s = 3600s
    Multi-density  : Pass density='low'/'medium'/'high' to switch route files.
    """

    def __init__(self, sumocfg=SUMO_CFG, use_gui=USE_GUI,
                 warmup=WARMUP_STEPS, ep_duration=EP_DURATION,
                 delta_t=DELTA_T, density: str = None):
        self.density  = density
        self.cfg      = self._resolve_config(sumocfg)
        self.use_gui  = use_gui
        self.warmup   = warmup
        self.ep_dur   = ep_duration
        self.delta_t  = delta_t
        self.sim_step = 0
        self._lane_cache:  dict = {}
        self._departed:    dict = {}
        self._arrived:     dict = {}
        self._green_hold:  dict = {}
        self._last_action: dict = {}

    def _resolve_config(self, base_cfg: str) -> str:
        if self.density is None:
            return base_cfg
        route_file = DENSITY_ROUTE_FILES.get(self.density, DEFAULT_ROUTE_FILE)
        if not os.path.exists(route_file):
            print(f"  [SUMOEnv] Warning: {route_file} not found, using {DEFAULT_ROUTE_FILE}")
            return base_cfg
        import xml.etree.ElementTree as ET
        cfg_path = f"run_{self.density}.sumocfg"
        net_file = "manhattan.net.xml"
        with open(cfg_path, "w") as f:
            f.write(f"""<configuration>
    <input>
        <net-file value="{net_file}"/>
        <route-files value="{route_file}"/>
    </input>
    <time>
        <begin value="0"/>
    </time>
</configuration>
""")
        print(f"  [SUMOEnv] density={self.density} → {route_file}")
        return cfg_path

    # ── Lifecycle ─────────────────────────────────────────────────────────────

    def _launch(self):
        binary = "sumo-gui" if self.use_gui else "sumo"
        traci.start([
            binary, "-c", self.cfg,
            "--step-length",      str(self.delta_t),
            "--time-to-teleport", "-1",
            "--no-warnings",      "true",
            "--log",              "/dev/null",
        ])

    def reset(self) -> dict:
        if traci.isLoaded():
            traci.close()
            time.sleep(0.2)
        self._launch()
        self.sim_step     = 0
        self._departed    = {}
        self._arrived     = {}
        self._lane_cache  = {}
        self._green_hold  = {jid: 0 for jid in REAL_JUNCTIONS}
        self._last_action = {jid: 0 for jid in REAL_JUNCTIONS}

        for _ in range(self.warmup):
            traci.simulationStep()
            self.sim_step += 1
            self._track_vehicles()

        self._build_lane_cache()
        return self._get_obs()

    def step(self, actions: dict):
        self._apply_actions(actions)
        traci.simulationStep()
        self.sim_step += 1
        self._track_vehicles()
        obs  = self._get_obs()
        rews = self._compute_rewards()
        done = self.sim_step >= (self.warmup + self.ep_dur)
        info = {"avg_tt": self.avg_tt(), "step": self.sim_step}
        return obs, rews, done, info

    def close(self):
        if traci.isLoaded():
            traci.close()

    # ── Lane cache ────────────────────────────────────────────────────────────

    def _build_lane_cache(self):
        for jid in REAL_JUNCTIONS:
            try:
                raw  = traci.trafficlight.getControlledLanes(jid)
                seen, dedup = set(), []
                for lid in raw:
                    if lid not in seen:
                        seen.add(lid)
                        dedup.append(lid)
                self._lane_cache[jid] = dedup
            except traci.TraCIException:
                self._lane_cache[jid] = []

    def _lanes(self, jid: str) -> list:
        if not self._lane_cache:
            self._build_lane_cache()
        return self._lane_cache.get(jid, [])

    # ── Observation ───────────────────────────────────────────────────────────

    def _get_obs(self) -> dict:
        out = {}
        for jid in REAL_JUNCTIONS:
            lanes  = self._lanes(jid)
            n      = JUNCTION_LANES[jid]
            counts = np.zeros(n, dtype=np.float32)
            for li, lid in enumerate(lanes[:n]):
                try:
                    c = 0
                    for vid in traci.lane.getLastStepVehicleIDs(lid):
                        pos = traci.vehicle.getLanePosition(vid)
                        if traci.lane.getLength(lid) - pos <= DETECTION_RANGE:
                            c += 1
                    counts[li] = float(c)
                except traci.TraCIException:
                    pass
            out[jid] = np.append(counts, float(self._last_action[jid])).astype(np.float32)
        return out

    # ── Reward ────────────────────────────────────────────────────────────────

    def _compute_rewards(self) -> dict:
        rews = {}
        for jid in REAL_JUNCTIONS:
            lanes = self._lanes(jid)
            q_list, d_list, w_list = [], [], []

            for lid in lanes:
                try:
                    n_veh      = traci.lane.getLastStepVehicleNumber(lid)
                    halting    = float(traci.lane.getLastStepHaltingNumber(lid))
                    q_list.append(halting)

                    free_v = traci.lane.getMaxSpeed(lid)
                    mean_v = traci.lane.getLastStepMeanSpeed(lid)
                    if free_v > 0:
                        d_list.append(max(0.0, 1.0 - mean_v / free_v))

                    total_wait = float(traci.lane.getWaitingTime(lid))
                    w_list.append(total_wait / max(1, n_veh))

                except traci.TraCIException:
                    pass

            q_mean = float(np.mean(q_list)) if q_list else 0.0
            d_mean = float(np.mean(d_list)) if d_list else 0.0
            w_mean = float(np.mean(w_list)) if w_list else 0.0

            rews[jid] = -(
                W_QUEUE * min(q_mean, Q_MAX) / Q_MAX +
                W_DELAY * min(d_mean, 1.0)           +
                W_WAIT  * min(w_mean, W_MAX) / W_MAX
            )
        return rews

    # ── Signal Control ────────────────────────────────────────────────────────

    def _apply_actions(self, actions: dict):
        """
        Apply DQN actions with SUMO-native yellow timer.
        Logic identical to MAPPO version — discrete action index (argmax Q)
        maps to a green phase, same 3-rule approach applies.

        Rule 1: ODD phase (yellow active) → do NOT call setPhase.
        Rule 2: green_hold < MIN_GREEN_STEPS → hold current green.
        Rule 3: switch allowed → setPhase(current + 1) once.
        """
        for jid, agent_action in actions.items():
            try:
                gps           = GREEN_PHASES[jid]
                agent_action  = int(agent_action) % len(gps)
                desired_green = gps[agent_action]

                current_phase = traci.trafficlight.getPhase(jid)

                # Rule 1: yellow is active → hands off
                if current_phase % 2 == 1:
                    self._green_hold[jid] = 0
                    continue

                # Rule 2: minimum green hold
                self._green_hold[jid] += 1
                min_met = self._green_hold[jid] >= MIN_GREEN_STEPS

                if desired_green != current_phase and min_met:
                    # Rule 3: initiate switch via yellow
                    traci.trafficlight.setPhase(jid, current_phase + 1)
                    self._green_hold[jid]  = 0
                    self._last_action[jid] = agent_action
                else:
                    if current_phase not in gps:
                        traci.trafficlight.setPhase(jid, desired_green)
                    else:
                        traci.trafficlight.setPhase(jid, current_phase)
                    self._last_action[jid] = (gps.index(current_phase)
                                              if current_phase in gps
                                              else agent_action)

            except (traci.TraCIException, KeyError, ValueError):
                pass

    # ── Vehicle tracking ──────────────────────────────────────────────────────

    def _track_vehicles(self):
        t = self.sim_step * self.delta_t
        for vid in traci.vehicle.getIDList():
            if vid not in self._departed:
                self._departed[vid] = t
        for vid in traci.simulation.getArrivedIDList():
            if vid in self._departed:
                self._arrived[vid] = t - self._departed[vid]

    def avg_tt(self) -> float:
        return float(np.mean(list(self._arrived.values()))) if self._arrived else 0.0


# ══════════════════════════════════════════════════════════════════════════════
#  HELPER FUNCTIONS
# ══════════════════════════════════════════════════════════════════════════════

def _get_density_for_episode(ep: int, n_episodes: int) -> str:
    """
    Curriculum schedule:
      Stage 1 (first 25%):  low
      Stage 2 (next 25%):   medium
      Stage 3 (last 50%):   high
    """
    frac = ep / n_episodes
    if frac < 0.25:
        return "low"
    elif frac < 0.50:
        return "medium"
    else:
        return "high"


def _save_log(log: list, directory: str):
    os.makedirs(directory, exist_ok=True)
    path = os.path.join(directory, "training_log.csv")
    with open(path, "w") as f:
        f.write("episode,avg_reward,avg_travel_time,avg_loss,epsilon,buffer_size,density\n")
        for r in log:
            f.write(f"{r['ep']},{r['avg_rew']:.4f},{r['avg_tt']:.2f},"
                    f"{r.get('avg_loss', 0.0):.6f},{r.get('epsilon', 0.0):.4f},"
                    f"{r.get('buffer_size', 0)},{r.get('density', 'default')}\n")
    print(f"  Log saved -> {path}")


# ══════════════════════════════════════════════════════════════════════════════
#  TRAINING LOOP  — DQN specific
# ══════════════════════════════════════════════════════════════════════════════

def train(n_episodes: int = MAX_EPISODES,
          device:     str = "cpu",
          save_dir:   str = "ckpt_dqn",
          resume_from: str = None,
          use_gui:    bool = False,
          curriculum: bool = False,
          density:    str = None):
    """
    GCN + Multi-Agent DQN training loop.

    Key differences from MAPPO training loop:
      - No rollout buffer: update() called every step (but internally DQN
        only trains once replay buffer has >= BATCH_SIZE transitions).
      - ctrl.update() takes (raw_obs, rewards, done) — pushes to replay buffer
        and samples a mini-batch if buffer is ready.
      - ctrl.decay_epsilon() called once per episode after env.close().
      - Logging includes dqn_loss, epsilon, and replay buffer size.
      - Target network copied every TARGET_UPDATE steps (handled inside MADQNAgent).

    Episode structure (same as MAPPO for fair comparison):
      900s  warm-up  — SUMO fixed-time plan, no agent
      2700s training — agent controls, DQN updated from replay buffer every step
      Total: 3600s per episode
    """
    print("=" * 70)
    print(f"  GCN-MA-DQN Training  |  device={device}  |  episodes={n_episodes}")
    print("  Algorithm  : DQN — deep Q-network + replay buffer + target network")
    print("  Reward     : -(0.5·NormQueue + 0.3·NormDelay + 0.2·NormWait)")
    print("  Update     : Batch TD, replay buffer per agent, target network")
    print(f"  Curriculum : {'ON' if curriculum else 'OFF'}")
    print("=" * 70)

    ctrl = MADQNController(device=device)
    if resume_from:
        ctrl.load(resume_from)

    best_tt = float("inf")
    ep_log  = []

    for ep in range(1, n_episodes + 1):
        ep_density = _get_density_for_episode(ep, n_episodes) if curriculum else density
        env        = SUMOEnv(use_gui=use_gui, density=ep_density)

        t0      = time.time()
        raw_obs = env.reset()
        ep_rew  = defaultdict(float)
        done    = False
        step_n  = 0
        ep_loss = []

        while not done:
            # DQN: act → step → push to replay buffer → train if buffer ready
            actions               = ctrl.act(raw_obs)
            raw_obs, rews, done, info = env.step(actions)

            # Pushes transitions to replay buffer; trains only when buffer ready
            log = ctrl.update(raw_obs, rews, done)
            ep_loss.append(log["dqn_loss"])

            for jid in REAL_JUNCTIONS:
                ep_rew[jid] += rews.get(jid, 0.0)
            step_n += 1

        env.close()
        ctrl.decay_epsilon()   # epsilon decay once per episode

        avg_rew     = float(np.mean(list(ep_rew.values())))
        avg_tt      = env.avg_tt()
        avg_loss    = float(np.mean(ep_loss)) if ep_loss else 0.0
        # Report replay buffer size of one representative agent
        buf_size    = len(ctrl.agents[REAL_JUNCTIONS[0]].replay)

        ep_log.append({
            "ep":          ep,
            "avg_rew":     avg_rew,
            "avg_tt":      avg_tt,
            "avg_loss":    avg_loss,
            "epsilon":     ctrl.epsilon[0],
            "buffer_size": buf_size,
            "density":     ep_density or "default",
        })

        dens_tag = f"[{ep_density or 'default':7s}]"
        print(f"  Ep {ep:4d}/{n_episodes} {dens_tag} | "
              f"reward={avg_rew:7.4f} | tt={avg_tt:6.1f}s | "
              f"loss={avg_loss:.4f} | ε={ctrl.epsilon[0]:.3f} | "
              f"buf={buf_size:5d} | steps={step_n:5d} | t={time.time()-t0:.0f}s")

        if ep % 50 == 0:
            ctrl.save(save_dir)
        if avg_tt > 0 and avg_tt < best_tt:
            best_tt = avg_tt
            ctrl.save(save_dir + "_best")
            print(f"  ★  New best travel time: {best_tt:.1f}s")

    ctrl.save(save_dir + "_final")
    _save_log(ep_log, save_dir)
    print(f"\n  Training complete. Best avg travel time: {best_tt:.1f}s")
    return ctrl


def _evaluate(ctrl: MADQNController, n_reps: int = 5, use_gui: bool = False,
              density: str = None):
    """Run evaluation episodes — no parameter updates, epsilon forced to 0."""
    saved_eps = ctrl.epsilon[0]
    ctrl.epsilon[0] = 0.0   # pure greedy (argmax Q) during evaluation

    tt_l, r_l = [], []
    for _ in range(n_reps):
        env  = SUMOEnv(use_gui=use_gui, density=density)
        raw  = env.reset()
        done = False
        ep_r = defaultdict(float)
        while not done:
            acts    = ctrl.act(raw)
            raw, rews, done, _ = env.step(acts)
            for jid in REAL_JUNCTIONS:
                ep_r[jid] += rews.get(jid, 0.0)
        tt_l.append(env.avg_tt())
        r_l.append(float(np.mean(list(ep_r.values()))))
        env.close()

    ctrl.epsilon[0] = saved_eps   # restore epsilon
    print(f"  Eval ({n_reps} reps): "
          f"travel_time = {np.mean(tt_l):.1f} ± {np.std(tt_l):.1f}s  |  "
          f"reward = {np.mean(r_l):.4f}")


# ══════════════════════════════════════════════════════════════════════════════
#  ENTRY POINT
# ══════════════════════════════════════════════════════════════════════════════

if __name__ == "__main__":
    import argparse
    p = argparse.ArgumentParser(description="GCN + Multi-Agent DQN Traffic Signal Training")
    p.add_argument("--episodes",   type=int,  default=MAX_EPISODES)
    p.add_argument("--device",     type=str,  default="cpu", choices=["cpu", "cuda"])
    p.add_argument("--save_dir",   type=str,  default="ckpt_dqn")
    p.add_argument("--resume",     type=str,  default=None)
    p.add_argument("--gui",        action="store_true")
    p.add_argument("--eval_only",  action="store_true")
    p.add_argument("--curriculum", action="store_true")
    p.add_argument("--density",    type=str,  default=None,
                   choices=["low", "medium", "high"])
    args = p.parse_args()

    if args.eval_only:
        ctrl = MADQNController(device=args.device)
        if args.resume:
            ctrl.load(args.resume)
        _evaluate(ctrl, n_reps=10, use_gui=args.gui, density=args.density)
    else:
        train(n_episodes  = args.episodes,
              device       = args.device,
              save_dir     = args.save_dir,
              resume_from  = args.resume,
              use_gui      = args.gui,
              curriculum   = args.curriculum,
              density      = args.density)
