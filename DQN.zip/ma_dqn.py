"""
ma_dqn.py
=========
Multi-Agent Deep Q-Network (DQN) with GCN encoder for Manhattan 4x4.

KEY DESIGN DECISIONS (important for paper comparison):
──────────────────────────────────────────────────────
  • Q-network   : Deep MLP (2 hidden layers, 64→128 neurons)
                  Mirrors MAPPO Actor depth for fair architectural comparison.
  • Replay buffer: YES — stores (s, a, r, s', done) transitions.
                  Breaks temporal correlations → more stable training.
  • Target network: YES — separate Q-net updated every TARGET_UPDATE steps.
                  Prevents moving-target problem that destabilises Q-learning.
  • Exploration : ε-greedy with exponential decay.
  • GCN         : Shared MultiLayerGCN (identical to MAPPO/Q-learning).
  • Execution   : Fully decentralised — each junction has its own DQN.

DIFFERENCES FROM Q-LEARNING (ma_qlearning.py):
  Q-Learning      DQN (this file)
  ─────────────   ───────────────────────────────────────
  Linear (1 layer)  Deep MLP (3 layers)
  No replay buffer  Replay buffer (BUFFER_SIZE=10,000)
  No target network Target network (hard copy every 200 steps)
  Online update     Batch update (BATCH_SIZE=64)

DIFFERENCES FROM MAPPO (mappo_atsc.py):
  DQN                          MAPPO
  ──────────────────────────   ─────────────────────────────────
  Value-based (Q-values)       Policy-based (action probabilities)
  ε-greedy exploration         Entropy-regularised exploration
  No centralised critic        Centralised Critic V(global_state)
  Independent agents           Shared critic across all agents
  Replay buffer                Rollout buffer + GAE

Reward (from traci_env):
  R = -(0.5·NormQueue + 0.3·NormDelay + 0.2·NormWait)  ∈ [-1, 0]
  Identical reward signal used by all three algorithms for fair comparison.

Compatible with:
  gcn_encoder.py   — MultiLayerGCN, get_augmented_obs_dims, ACT_DIM
  traci_env_dqn.py — training loop, SUMOEnv, _evaluate()
"""

import os
import time
import random
from collections import deque, defaultdict

import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F
import torch.optim as optim

from gcn_encoder import (
    MultiLayerGCN, get_augmented_obs_dims,
    REAL_JUNCTIONS, RAW_OBS_DIM, ACT_DIM, GCN_OUT_DIM,
)

# ─────────────────────────────────────────────────────────────────────────────
#  HYPERPARAMETERS
# ─────────────────────────────────────────────────────────────────────────────

GAMMA         = 0.99      # discount factor
LR_DQN        = 1e-3      # learning rate
BUFFER_SIZE   = 10_000    # replay buffer capacity per agent
BATCH_SIZE    = 64        # mini-batch size for training
TARGET_UPDATE = 200       # hard target network copy every N steps
EPS_START     = 1.0       # initial ε for ε-greedy
EPS_END       = 0.05      # minimum ε
EPS_DECAY     = 0.995     # per-episode ε decay (same as Q-learning for fair comparison)
GRAD_CLIP     = 0.5       # gradient clipping
WARMUP_STEPS  = 500       # steps before first update (fill replay buffer first)
MAX_EPISODES  = 1000

AUG_OBS_DIM  = get_augmented_obs_dims()   # {jid: int}


# ─────────────────────────────────────────────────────────────────────────────
#  DEEP Q-NETWORK  (3 layers — deep, unlike linear Q-learning)
# ─────────────────────────────────────────────────────────────────────────────

class DeepQNetwork(nn.Module):
    """
    Q(s, a) with 2 hidden layers.
    Matches MAPPO Actor depth for fair architectural comparison.

    Architecture: obs_dim → 64 → ReLU → 128 → ReLU → action_dim
    Output: Q-values for all actions, shape (action_dim,).

    The depth is intentionally the same as the MAPPO Actor so that any
    performance difference comes from the RL algorithm (policy-based vs
    value-based), not from network capacity.
    """
    def __init__(self, obs_dim: int, action_dim: int):
        super().__init__()
        self.net = nn.Sequential(
            nn.Linear(obs_dim,  64),  nn.ReLU(),
            nn.Linear(64,      128),  nn.ReLU(),
            nn.Linear(128, action_dim),
        )
        nn.init.orthogonal_(self.net[-1].weight, gain=1.0)
        nn.init.zeros_(self.net[-1].bias)

    def forward(self, obs: torch.Tensor) -> torch.Tensor:
        return self.net(obs)


# ─────────────────────────────────────────────────────────────────────────────
#  REPLAY BUFFER
# ─────────────────────────────────────────────────────────────────────────────

class ReplayBuffer:
    """
    Experience replay buffer.
    Stores (obs, action, reward, next_obs, done) tuples.
    Sampling breaks temporal correlations → stabler gradient updates.
    """
    def __init__(self, capacity: int, obs_dim: int):
        self.capacity = capacity
        self.obs_dim  = obs_dim
        self.buffer   = deque(maxlen=capacity)

    def push(self, obs: np.ndarray, action: int, reward: float,
             next_obs: np.ndarray, done: bool):
        self.buffer.append((obs, action, reward, next_obs, float(done)))

    def sample(self, batch_size: int, device: torch.device):
        batch = random.sample(self.buffer, batch_size)
        obs, acts, rews, next_obs, dones = zip(*batch)
        return (
            torch.FloatTensor(np.array(obs)).to(device),
            torch.LongTensor(acts).to(device),
            torch.FloatTensor(rews).to(device),
            torch.FloatTensor(np.array(next_obs)).to(device),
            torch.FloatTensor(dones).to(device),
        )

    def __len__(self):
        return len(self.buffer)

    @property
    def ready(self):
        return len(self.buffer) >= BATCH_SIZE


# ─────────────────────────────────────────────────────────────────────────────
#  PER-JUNCTION DQN AGENT
# ─────────────────────────────────────────────────────────────────────────────

class MADQNAgent:
    """
    Single-junction DQN agent.
    Uses experience replay + target network for training stability.
    """
    def __init__(self, jid: str, device: torch.device, epsilon_ref: list):
        self.jid          = jid
        self.dev          = device
        self.na           = ACT_DIM[jid]
        self.epsilon_ref  = epsilon_ref   # shared reference with controller
        obs_dim           = AUG_OBS_DIM[jid]

        # Online network: updated every BATCH_SIZE steps
        self.q_net        = DeepQNetwork(obs_dim, self.na).to(device)
        # Target network: copied from q_net every TARGET_UPDATE steps
        self.target_net   = DeepQNetwork(obs_dim, self.na).to(device)
        self.target_net.load_state_dict(self.q_net.state_dict())
        self.target_net.eval()

        self.optimizer    = optim.Adam(self.q_net.parameters(), lr=LR_DQN)
        self.replay       = ReplayBuffer(BUFFER_SIZE, obs_dim)

        # Transition memory for current step
        self._prev_obs    = None
        self._prev_action = None
        self.steps        = 0
        self.total_loss   = 0.0

    @torch.no_grad()
    def act(self, aug_obs: np.ndarray) -> int:
        """ε-greedy action selection using online Q-network."""
        if np.random.random() < self.epsilon_ref[0]:
            return np.random.randint(0, self.na)
        obs_t  = torch.FloatTensor(aug_obs).unsqueeze(0).to(self.dev)
        q_vals = self.q_net(obs_t)
        return int(q_vals.argmax(dim=1).item())

    def store(self, aug_obs: np.ndarray, action: int):
        """Cache current step's obs + action for replay buffer push."""
        self._prev_obs    = aug_obs
        self._prev_action = action

    def push_to_replay(self, reward: float, next_obs: np.ndarray, done: bool):
        """Push completed transition (s, a, r, s', done) to replay buffer."""
        if self._prev_obs is not None:
            self.replay.push(self._prev_obs, self._prev_action,
                             reward, next_obs, done)

    def update(self) -> float:
        """
        Sample a mini-batch from replay buffer and perform one gradient step.
        Only called when buffer has enough samples (>= BATCH_SIZE).

        Loss: MSE( Q(s,a),  r + γ·max_a' Q_target(s',a') )
        Target network is used for bootstrap — prevents moving-target instability.
        """
        if not self.replay.ready:
            return 0.0

        obs, acts, rews, next_obs, dones = self.replay.sample(BATCH_SIZE, self.dev)

        # Q-values for actions actually taken
        q_current = self.q_net(obs).gather(1, acts.unsqueeze(1)).squeeze(1)

        # Bootstrap target using frozen target network
        with torch.no_grad():
            q_next   = self.target_net(next_obs).max(dim=1)[0]
            q_target = rews + GAMMA * q_next * (1.0 - dones)

        loss = F.mse_loss(q_current, q_target)

        self.optimizer.zero_grad()
        loss.backward()
        nn.utils.clip_grad_norm_(self.q_net.parameters(), GRAD_CLIP)
        self.optimizer.step()

        self.steps      += 1
        self.total_loss += loss.item()

        # Hard copy online → target every TARGET_UPDATE steps
        if self.steps % TARGET_UPDATE == 0:
            self.target_net.load_state_dict(self.q_net.state_dict())

        return loss.item()

    def save(self, path: str):
        torch.save({
            "q_net":      self.q_net.state_dict(),
            "target_net": self.target_net.state_dict(),
            "steps":      self.steps,
        }, path)

    def load(self, path: str):
        ck = torch.load(path, map_location=self.dev)
        self.q_net.load_state_dict(ck["q_net"])
        self.target_net.load_state_dict(ck["target_net"])
        self.steps = ck.get("steps", 0)


# ─────────────────────────────────────────────────────────────────────────────
#  MA DQN CONTROLLER
# ─────────────────────────────────────────────────────────────────────────────

class MADQNController:
    """
    Coordinates all per-junction DQN agents with shared GCN encoder.

    Drop-in replacement for MAPPOController and MAQLController — same
    act() / update() interface so the training loop can be reused.

    Key differences from MAQLController (Q-learning):
      • Deep Q-network (3 layers) vs linear (1 layer)
      • Experience replay buffer vs no buffer
      • Target network vs no target network
      • Batch updates vs online updates

    Key differences from MAPPOController (MAPPO):
      • No centralised critic
      • Value-based policy (argmax Q) vs stochastic policy (Categorical)
      • Epsilon-greedy vs entropy-regularised exploration
    """
    def __init__(self, device: str = "cpu", gcn_ckpt: str = None):
        self.dev       = torch.device(device)
        self.gcn       = MultiLayerGCN(device=device).to(self.dev)
        if gcn_ckpt and os.path.exists(gcn_ckpt):
            self.gcn.load_state_dict(torch.load(gcn_ckpt, map_location=self.dev))

        self.epsilon     = [EPS_START]   # shared mutable reference
        self.agents      = {jid: MADQNAgent(jid, self.dev, self.epsilon)
                            for jid in REAL_JUNCTIONS}
        self.global_step = 0
        self._aug_obs    = {}    # cached from current act() call
        self._print_summary()

    def _print_summary(self):
        gcn_p = sum(p.numel() for p in self.gcn.parameters())
        q_p   = sum(p.numel() for p in self.agents["n_1_1"].q_net.parameters())
        total = gcn_p + q_p * 2 * len(self.agents)   # ×2 for target network
        print(f"\n  MADQNController ready")
        print(f"  Algorithm   : DQN  |  Q-network: Deep MLP (64→128→act)")
        print(f"  Junctions   : {len(self.agents)}")
        print(f"  GCN params  : {gcn_p:,}   DQN per agent: {q_p:,}   Total: {total:,}")
        print(f"  Buffer size : {BUFFER_SIZE:,} transitions per agent")
        print(f"  Target update: every {TARGET_UPDATE} steps (hard copy)")
        print(f"  Epsilon     : {EPS_START} → {EPS_END}  (decay {EPS_DECAY}/episode)")

    def act(self, raw_obs: dict):
        """
        Encode observations via GCN, then select ε-greedy actions.
        Caches aug_obs for replay buffer push in update().
        """
        self._aug_obs = self.gcn.augment_obs(raw_obs)
        actions = {}
        for jid, agent in self.agents.items():
            a = agent.act(self._aug_obs[jid])
            agent.store(self._aug_obs[jid], a)
            actions[jid] = a
        return actions

    def update(self, raw_obs: dict, rewards: dict, done: bool) -> dict:
        """
        1. Push transitions to replay buffers.
        2. Sample and train if buffer is ready.
        Called every simulation step (same frequency as Q-learning).
        """
        next_aug = self.gcn.augment_obs(raw_obs)
        losses   = []

        for jid, agent in self.agents.items():
            r = rewards.get(jid, 0.0)
            # Push to replay buffer
            agent.push_to_replay(r, next_aug[jid], done)
            # Train from replay buffer (no-op if buffer not ready yet)
            loss = agent.update()
            losses.append(loss)

        self.global_step += 1
        return {"dqn_loss": float(np.mean(losses)), "epsilon": self.epsilon[0]}

    def decay_epsilon(self):
        """Call once per episode after the episode ends."""
        self.epsilon[0] = max(EPS_END, self.epsilon[0] * EPS_DECAY)

    def save(self, directory: str = "ckpt_dqn"):
        os.makedirs(directory, exist_ok=True)
        torch.save(self.gcn.state_dict(), os.path.join(directory, "gcn.pt"))
        for jid, agent in self.agents.items():
            agent.save(os.path.join(directory, f"dqn_{jid}.pt"))
        print(f"  Saved -> {directory}/")

    def load(self, directory: str = "ckpt_dqn"):
        p = os.path.join(directory, "gcn.pt")
        if os.path.exists(p):
            self.gcn.load_state_dict(torch.load(p, map_location=self.dev))
        for jid, agent in self.agents.items():
            p = os.path.join(directory, f"dqn_{jid}.pt")
            if os.path.exists(p):
                agent.load(p)
        print(f"  Loaded <- {directory}/")


# ─────────────────────────────────────────────────────────────────────────────
#  TRAINING LOOP
# ─────────────────────────────────────────────────────────────────────────────


# Training loop is in traci_env_dqn.py
# Run: python traci_env_dqn.py --episodes 500 --density high
